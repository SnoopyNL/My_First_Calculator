# My_First_Calculator

# I haven't open this project for a while and now, when I'm trying to build my calculator, it keeps on loading indefinitely. 
# There are a lot of warnings and errors in the code. Parts of the code that used to work properly are now 'not allowed' to use it like the way I did. I think it might be because of some updates of Android Studio. 
# Long story short, to much to handle (to fix) for me. 
